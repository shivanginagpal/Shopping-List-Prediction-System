module.exports = {
  mongoURI:
    "mongodb+srv://shivangi_295:shivangi_295@cluster0-9s6qc.mongodb.net/test?retryWrites=true&w=majority",
  secret: "This too shall pass!!",
  awsBucket: "groceryprediction295",
  // Keys can't be added here because AWS categorizes this as vulnerability.
  awsAccessKey: "AKIAIDECVU66QXAUP3SQ",
  awsSecretAccessKey: "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",
  awsPermission: "public-read",
};
