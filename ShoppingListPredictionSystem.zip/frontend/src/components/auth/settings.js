const hostaddress = "localhost";
module.exports = { hostaddress };
