import React from 'react'

export default function Footer() {
    return (
            <footer className="bg-dark text-white mt-5 p-4 text-center">
                Grocery Application &copy; CMPE 295 A Project Adv: Prof Weider Yu
            </footer>
    )
}
