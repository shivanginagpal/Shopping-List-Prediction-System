export const GET_ERRORS = 'GET_ERRORS';
export const SET_CURRENT_USER = 'SET_CURRENT_USER';
export const GET_USER = 'GET_USER';
export const USER_LOADING = 'USER_LOADING';
export const USER_NOT_FOUND = 'USER_NOT_FOUND';
export const CLEAR_CURRENT_USER = 'CLEAR_CURRENT_USER';

